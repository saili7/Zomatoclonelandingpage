# This is my zomato landing page clone.

## Done with first commit.

## Done some new adjustments.
